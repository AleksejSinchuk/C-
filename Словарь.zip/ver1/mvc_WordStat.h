#pragma once
#include "BaseController.h"
#include "BaseView.h"
#include "BaseModel.h"


//*--------------------------------------------------------------------------------
class WordStatModel : public BaseModel
{
public:
	static WordStatModel* Instance();
	bool DeleteInstance();
protected:
	static WordStatModel* _self;
	virtual ~WordStatModel() {};

	WordStatModel();

};


//*--------------------------------------------------------------------------------
class WordStatController :
	public BaseController
{

public:
	virtual void renderMenu() override;
	bool doFileAnalistic();
	WordStatController();
	~WordStatController();
};
