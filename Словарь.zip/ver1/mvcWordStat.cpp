/*
*
* @ver 1
* @autor Oleksandr Nykytin aka Keeper
* @url https://www.ninydev.com
*/

#include <iostream>
#include <string>
#include <time.h>
#include <Windows.h>
using namespace std;
//*--------------------------------------------------------------------------------
#include "mvc_WordStat.h"



void main()
{
	setlocale(LC_ALL, "Russian");
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	srand(time(NULL));

	WordStatController* ws =  new WordStatController();
	ws->renderMenu();


	// 	cout << "\n ___________________________________________________________________ \n";

	//*--------------------------------------------------------------------------------
	cout << endl << endl;
}