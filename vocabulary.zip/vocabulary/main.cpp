#include <iostream>
#include <string>
#include <vector>
#include <Windows.h>
#include "VocBaseModel.h"
#include "VocBaseView.h"
#include "VocBaseController.h"
#include "Vocabr.h"
using namespace std;
//*--------------------------------------------------------------------------------


int main() {
	setlocale(LC_ALL, "");
	SetConsoleOutputCP(1251);
	SetConsoleCP(1251);

	Vocabr*V = new Vocabr;
	V->renderMenu();
	
	system("pause");
}