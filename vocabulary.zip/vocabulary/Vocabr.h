#pragma once
#include "VocBaseModel.h"
#include "VocBaseView.h"
#include "VocBaseController.h"

class Vocabr :
	public VocBaseController
{
public:
	Vocabr();
	~Vocabr();
};

