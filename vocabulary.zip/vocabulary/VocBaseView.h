#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <map>
using namespace std;

class VocBaseView
{
public:
	VocBaseView();
	~VocBaseView();

	
	//*--------------------------------------------------------------------------------
	string menuTitle;
	vector<string>menuItem;
	//*--------------------------------------------------------------------------------
	void changeMenuTitle(string menuTitle) { this->menuTitle = menuTitle; };
	void changeMenuTitle(char* menuTitle) { this->menuTitle = menuTitle; }
	void addMenuItem(string );
	char showMenu();
	void showText(char*);
	bool searchWord(map <string, int> *data);

	bool frequentWord(map <string, int> *data);

	string addWord();
	void showVocab(map <string, int> *data);

};

