#pragma once
#include "VocBaseView.h"
#include "VocBaseModel.h"
class VocBaseController
{
public:
	VocBaseController();
	~VocBaseController();

	virtual void renderMenu();
	bool doStandartMenuSwitch(char userChoise);
	virtual void buildMenu();


	VocBaseModel *model;
	VocBaseView *view;
};

