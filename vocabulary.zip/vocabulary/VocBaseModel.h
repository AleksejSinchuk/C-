#pragma once
#include <iostream>
#include <map>
#include <stdio.h>
#include <conio.h>
#include <fstream>
#include <string>
using namespace std;
class VocBaseModel
{
public:
	VocBaseModel();
	~VocBaseModel();
	
	//*--------------------------------------------------------------------------------
	char* readTextFromFile(string nameFile);
	map <string, int>* loadWordsInVoc(char*text);
	map <string, int>* searchWord(string word);
	bool addWord(string word);
	bool update(string word);
	bool loadVocInFile();


	map <string, int> *list;
	string fileName;
	char*tmp;
};

